import React from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from "yup";

const schema = yup.object().shape({
  userName: yup.string().required().min(5),
  age: yup.number().positive().integer().required(),
});

function YupForm() {
  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: yupResolver(schema)
  });
  const onSubmit = data => console.log(data);

  return (
    <div>
      <h1>yup and REACT-HOOK-FORM</h1>
      <form onSubmit={handleSubmit(onSubmit)}>
        <label>UserName</label>
        <br />
        <input {...register("userName")} />
        <p style={{ color: "red" }}>{errors.userName?.message}</p>
        <label>Age</label>
        <br />
        <input {...register("age")} />
        <p style={{ color: "red" }}>{errors.age?.message}</p>

        <input type="submit"/>
      </form>
    </div>

  );
}
export default YupForm;
