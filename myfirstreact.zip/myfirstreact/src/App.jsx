import React from 'react';
import { BrowserRouter as Router, Switch, Route ,Link} from 'react-router-dom';
// import { Route, Link, Switch, Router } from "react-router-dom";

import './App.css';
import NewHookForm from './newhookform';
import Login from './Login';

import Form from './form';
import ReactHookForm from './react_hook_form';
import YupForm from './usingyupform';


function App() {
  return (
    <Router>
      <div>
         {/* <button>
          <Link to="/newform">Functional hook form</Link>
        </button> */}
        <button>
          <Link to="/form">Functional hook form</Link>
        </button>
        <button>
          <Link to="/hookform">react-hook-form</Link>
        </button>
        <button>
          <Link to="/yupform">using yup and react-hook-form</Link>
        </button>
         <button>
          <Link to="/login">email and password </Link>
        </button>

      </div>

      <Switch>
        <Route exact path="/newform" component={NewHookForm} />
        <Route exact path="/form" component={Form} />
        <Route exact path="/hookform" component={ReactHookForm} />
        <Route exact path="/yupform" component={YupForm} />
        <Route exact path="/login" component={Login} />



      </Switch>

    </Router>
  );

}

export default App;
