import React, { useState } from 'react';
import './App.css';
import validate from './'

function Form() {
    const [formData, setFormData] = useState({
        username: '',
        age: 0,
        remember: false,
        domain: ''
    });
    const [errors, setErrors] = useState({});

    function validate({ username }) {
        const valid = username && username.length > 3;
        if (!valid) {
            setErrors({ username: true });
        } else {
            setErrors({})
        }
        return valid;

    }
    function onSubmit(event) {
        event.preventDefault();
        validate(formData) ? console.log(formData) : console.log('invalid');
    }
    function onChange({ target }) {
        const value = target.type === "checkbox" ? target.checked : target.value;
        setFormData(prevState => ({
            ...prevState,
            [target.name]: value
        }))
    }
    return (
        <div>
            <h1>Functional REACT-HOOK-FORM</h1>
            <p>{formData.username}</p>
            <p>{formData.age}</p>
            <p>{formData.remember ? "checked" : "unchecked"}</p>
            <p>{formData.domain}</p>
            <form onSubmit={onSubmit}>
                <div>
                    <label>UserName</label>
                    <br />
                    <input type="text" name="email" value={formData.username} onChange={onChange} />
                    {errors.username && <p style={{ color: "red" }}>Username invalid</p>}
                </div>
                <div>
                    <label>Age</label>
                    <br />
                    <input type="text" name="age" value={formData.age} onChange={onChange} />
                </div>
                <div>
                    <label>Department</label>
                    <br />
                    <select name="domain" value={formData.domain} onChange={onChange}>
                        <option>choose</option>
                        <option>Mechanical</option>
                        <option>CSE</option>
                        <option>EEE</option>
                    </select>
                </div>
                <span>
                    <div>
                        <input type="checkbox" name="remember" value={formData.remember} onChange={onChange} />
                        <label>Remember me</label>
                    </div>
                </span>
                <button type="submit">Sumbit</button>
            </form>


        </div>
    );
}

export default Form;
