import './App.css';
import {useForm} from "react-hook-form";

function ReactHookForm() {
    
  const {handleSubmit,register, formState: { errors },reset}=useForm({});
  

  const onSubmit = (data) => {
    var a=data;
    console.log(a);
    reset()
  };


  return (
    <div>
      <h1>REACT-HOOK-FORM</h1>
           
      <form onSubmit={handleSubmit(onSubmit)}>
        <div>
          <label>UserName</label>
          <br />
          <input {...register("username",{required:true,minLength:3 })}/>
          {errors.username && <p style={{color: "red"}}>Username invalid</p>}
        </div>
        <div>
          <label>Age</label>
          <br />
          <input type="text"{...register("age",{ pattern: /\d+/,required:true,maxLength:2  })}/>
          {errors.age && <p style={{color: "red"}}>age invalid</p>}

        </div>
        <div>
                    <label>Department</label>
                    <br />
                    <select {...register("domain",{required:true })}>
                        <option>choose</option>
                        <option>Mechanical</option>
                        <option>CSE</option>
                        <option>EEE</option>
                    </select>
                    {errors.domain && <p style={{color: "red"}}>plz select domain</p>}
                    </div>
        <span>
          <div>
            <input type="checkbox"{...register("remember")} />
            <label>Remember me</label>
          </div>
        </span>
        <button type="submit">Sumbit</button>
      </form>

    </div>
  );
}

export default ReactHookForm;
